"use client";
import { useEffect, useState } from "react";
import { getSession, signOut } from "next-auth/react";
import Link from "next/link";

export default function Dashboard(){
  const [session,setSession]=useState<any>(null);
  useEffect(()=>{ getSession().then(setSession); },[]);
  if (!session) return (<main className="px-6 py-20 text-center"><p>Please <a className="underline" href="/signin">sign in</a> to view the dashboard.</p></main>);

  return (
    <main className="max-w-6xl mx-auto px-6 py-10">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="flex items-center gap-2">
          <span className="badge">{session.user?.email}</span>
          <button className="btn btn-outline" onClick={()=>signOut({ callbackUrl: "/" })}>Sign out</button>
        </div>
      </div>
      <section className="grid md:grid-cols-3 gap-6 mt-8">
        {["AUM: $2.4B","Investors: 120k+","Uptime: 99.99%"].map((k,i)=>(<div key={i} className="card p-6 text-center font-semibold">{k}</div>))}
      </section>
      <section className="grid md:grid-cols-2 gap-6 mt-8">
        <div className="card p-6"><h2 className="text-xl font-semibold mb-2">Users</h2><p className="text-sm text-zinc-500">Demo list (connect DB later).</p></div>
        <div className="card p-6"><h2 className="text-xl font-semibold mb-2">Support Tickets</h2><p className="text-sm text-zinc-500">No open tickets.</p></div>
      </section>
      <section className="card p-6 mt-8">
        <h2 className="text-xl font-semibold mb-2">API Keys</h2>
        <p className="text-sm text-zinc-500 mb-4">Generate and manage API access (demo only).</p>
        <button className="btn btn-primary">Generate key</button>
      </section>
    </main>
  );
}
