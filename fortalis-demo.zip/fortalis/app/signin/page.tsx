"use client";
import { signIn } from "next-auth/react";
import { useState } from "react";
import Link from "next/link";

export default function SignIn(){
  const [email,setEmail]=useState("admin@fortalis.test");
  const [password,setPassword]=useState("demo1234");
  const [loading,setLoading]=useState(false);
  async function submit(e:any){ e.preventDefault(); setLoading(true);
    const res = await signIn("credentials", { email, password, redirect: true, callbackUrl: "/dashboard" });
    setLoading(false);
  }
  return (
    <main className="max-w-md mx-auto px-6 py-20">
      <h1 className="text-3xl font-bold">Sign in</h1>
      <p className="text-sm text-zinc-500 mt-1">Demo credentials are prefilled.</p>
      <form onSubmit={submit} className="card p-6 mt-6 space-y-3">
        <input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@domain.com"/>
        <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••"/>
        <button className="btn btn-primary w-full" disabled={loading}>{loading? "Signing in..." : "Sign in"}</button>
        <div className="text-sm text-center">No account? <Link href="/signup" className="underline">Create one</Link></div>
      </form>
    </main>
  );
}
