export default function Privacy(){
  return <main className="prose prose-zinc dark:prose-invert max-w-3xl mx-auto px-6 py-16">
    <h1>Privacy Policy</h1>
    <p>This template outlines how Fortalis may process personal data. Replace with counsel-approved text.</p>
    <h3>Data we collect</h3>
    <ul><li>Account details</li><li>Usage analytics</li><li>KYC/KYB information</li></ul>
    <h3>Security</h3>
    <p>We use encryption in transit and at rest; role-based access; audit logs.</p>
  </main>;
}
