export async function GET() {
  const body = `User-agent: *\nAllow: /\nSitemap: https://fortalis.example/sitemap.xml`;
  return new Response(body, { headers: { "content-type": "text/plain" } });
}
