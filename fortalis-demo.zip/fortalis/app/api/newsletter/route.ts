import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json().catch(()=>({}));
  const email = (body.email || "").toString().trim();
  if (!email.includes("@")) return NextResponse.json({ ok: false, error: "Invalid email" }, { status: 400 });
  console.log("[newsletter] subscribe:", email);
  return NextResponse.json({ ok: true });
}
