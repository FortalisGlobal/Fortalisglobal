"use client";
import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { name: "Jan", value: 200 }, { name: "Feb", value: 400 }, { name: "Mar", value: 350 },
  { name: "Apr", value: 500 }, { name: "May", value: 700 }, { name: "Jun", value: 650 },
];

export default function HomePage(){
  const [dark, setDark] = useState(true);
  useEffect(()=>{ const s = localStorage.getItem("theme"); if (s) setDark(s==="dark"); },[]);
  useEffect(()=>{ document.documentElement.classList.toggle("dark", dark); localStorage.setItem("theme", dark? "dark":"light"); },[dark]);
  return (
    <main>
      <section className="relative flex flex-col items-center justify-center text-center py-24 px-6 overflow-hidden">
        <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full blur-3xl bg-indigo-500/20" />
          <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full blur-3xl bg-cyan-500/20" />
        </div>
        <motion.h1 initial={{opacity:0,y:-20}} animate={{opacity:1,y:0}} transition={{duration:0.6}} className="text-5xl md:text-7xl font-bold">
          Fortalis — Global Investments
        </motion.h1>
        <motion.p initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:0.2}} className="mt-6 max-w-2xl text-lg md:text-xl text-zinc-500 dark:text-zinc-300">
          Secure, innovative, and future‑ready investment solutions. Built with next‑generation technology for a global audience.
        </motion.p>
        <div className="mt-10 flex gap-4">
          <Link href="/signup" className="btn btn-primary">Get Started</Link>
          <Link href="/enterprise" className="btn btn-outline">Book Enterprise Demo</Link>
          <button aria-label="Toggle theme" onClick={()=>setDark(v=>!v)} className="btn btn-outline">Toggle Theme</button>
        </div>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3 text-xs text-zinc-500">
          <span className="badge">KYC/KYB Ready</span>
          <span className="badge">AML Screening</span>
          <span className="badge">ISO 27001*</span>
          <span className="badge">SOC 2*</span>
        </div>
      </section>

      <section id="features" className="grid md:grid-cols-3 gap-6 px-6 md:px-16 py-16">
        {["Bank‑Grade Security","Smart Analytics","Global Community"].map((t,i)=>(
          <div key={i} className="card p-6 text-center">
            <h3 className="text-xl font-semibold mb-2">{t}</h3>
            <p className="text-zinc-500 dark:text-zinc-300">Enterprise-grade features presented simply.</p>
          </div>
        ))}
      </section>

      <section id="performance" className="py-16 px-6 md:px-16 bg-zinc-50 dark:bg-zinc-900/40">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-10">Performance Overview</h2>
        <div className="h-[320px] card p-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#2563eb" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section id="pricing" className="py-16 px-6 md:px-16">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-10">Simple, Transparent Pricing</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {[
            { name: "Starter", price: "Free", features: ["Multi‑asset portfolio","Basic analytics","Community support"], cta: "Create free account" },
            { name: "Pro", price: "$39/mo", features: ["Smart rebalancing","Tax‑aware trades","24/7 live chat","API access"], cta: "Start Pro trial", highlight: true },
            { name: "Enterprise", price: "Talk to us", features: ["SLA & SSO/SAML","Custom risk rules","Dedicated manager","On‑prem or VPC"], cta: "Book a demo" }
          ].map((p,i)=>(
            <div key={i} className={`card p-6 ${p.highlight? "border-indigo-500":""}`}>
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold">{p.name}</h3>
                {p.highlight && <span className="badge">Popular</span>}
              </div>
              <div className="text-4xl font-bold mt-2">{p.price}</div>
              <ul className="mt-4 space-y-2 text-sm text-zinc-500">
                {p.features.map((f,k)=>(<li key={k}>• {f}</li>))}
              </ul>
              <a className="btn btn-primary w-full mt-6" href="/signup">{p.cta}</a>
            </div>
          ))}
        </div>
      </section>

      <section id="support" className="py-16 px-6 md:px-16 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">24/7 Live Support</h2>
        <p className="max-w-2xl mx-auto text-lg text-zinc-500 dark:text-zinc-300">
          Our global support team is always available. Real‑time chat, multi‑language help, and personalized guidance.
        </p>
        <div className="mt-6 flex items-center justify-center gap-3">
          <a href="/contact" className="btn btn-outline">Request a call</a>
          <a href="#" className="btn btn-primary">Start chat</a>
        </div>
      </section>
    </main>
  );
}
