import "./globals.css";
import type { Metadata } from "next";
import { ReactNode } from "react";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Fortalis — Strong by Design",
  description: "Next‑gen investment platform: secure custody, global execution, quant analytics.",
  icons: [{ rel: "icon", url: "/favicon.ico" }]
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        {process.env.NEXT_PUBLIC_CRISP_WEBSITE_ID && (
          <script dangerouslySetInnerHTML={{ __html:
            `window.$crisp=[];window.CRISP_WEBSITE_ID="${process.env.NEXT_PUBLIC_CRISP_WEBSITE_ID}";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();`
          }}/>
        )}
      </head>
      <body className="min-h-screen antialiased">
        <header className="sticky top-0 z-50 backdrop-blur bg-white/60 dark:bg-zinc-950/60 border-b">
          <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
            <Link href="/" className="font-extrabold">FORTALIS</Link>
            <nav className="hidden md:flex gap-6 text-sm text-zinc-500">
              <Link href="/#features">Features</Link>
              <Link href="/#performance">Performance</Link>
              <Link href="/#pricing">Pricing</Link>
              <Link href="/#support">Support</Link>
            </nav>
            <div className="flex gap-2">
              <Link href="/signin" className="btn btn-outline">Sign in</Link>
              <Link href="/signup" className="btn btn-primary">Create account</Link>
            </div>
          </div>
        </header>
        {children}
        <footer className="py-10 px-6 md:px-16 border-t text-center">
          <p>© {new Date().getFullYear()} Fortalis. All rights reserved.</p>
          <div className="flex justify-center gap-4 mt-4 text-sm">
            <Link href="/privacy">Privacy</Link>
            <Link href="/terms">Terms</Link>
            <Link href="/disclosures">Disclosures</Link>
          </div>
        </footer>
      </body>
    </html>
  );
}
