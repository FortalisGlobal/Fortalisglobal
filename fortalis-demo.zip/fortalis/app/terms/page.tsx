export default function Terms(){
  return <main className="prose prose-zinc dark:prose-invert max-w-3xl mx-auto px-6 py-16">
    <h1>Terms of Service</h1>
    <p>These terms govern your use of Fortalis. Replace with legal review.</p>
    <h3>Acceptable Use</h3>
    <p>No unlawful activity, market manipulation, or prohibited jurisdictions.</p>
  </main>;
}
