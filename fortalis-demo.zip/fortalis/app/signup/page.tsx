"use client";
import { useState } from "react";
import Link from "next/link";

export default function SignUp(){
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  function submit(e:any){ e.preventDefault(); alert("Demo only. Use /signin with demo credentials."); }
  return (
    <main className="max-w-md mx-auto px-6 py-20">
      <h1 className="text-3xl font-bold">Create account</h1>
      <p className="text-sm text-zinc-500 mt-1">Demo signup UI; connect DB and email in production.</p>
      <form onSubmit={submit} className="card p-6 mt-6 space-y-3">
        <input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@domain.com"/>
        <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Create a password"/>
        <button className="btn btn-primary w-full">Create account</button>
        <div className="text-xs text-zinc-500">2FA available after sign-in (placeholder)</div>
        <div className="text-sm text-center">Already have an account? <Link href="/signin" className="underline">Sign in</Link></div>
      </form>
    </main>
  );
}
