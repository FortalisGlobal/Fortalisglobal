"use client";
import { useState } from "react";

export default function Contact(){
  const [name,setName]=useState(""), [email,setEmail]=useState(""), [msg,setMsg]=useState(""), [ok,setOk]=useState<string| null>(null);
  async function submit(e:any){ e.preventDefault(); setOk(null);
    const res = await fetch('/api/contact', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ name, email, message: msg }) });
    const j = await res.json(); setOk(j.ok? "Thanks — we’ll be in touch." : "Something went wrong");
  }
  return <main className="max-w-md mx-auto px-6 py-16">
    <h1 className="text-3xl font-bold">Contact us</h1>
    <form onSubmit={submit} className="card p-6 mt-6 space-y-3">
      <input className="input" placeholder="Name" value={name} onChange={e=>setName(e.target.value)}/>
      <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/>
      <textarea className="input" placeholder="Message" value={msg} onChange={e=>setMsg(e.target.value)} rows={4}/>
      <button className="btn btn-primary w-full">Send</button>
      {ok && <div className="text-sm text-center">{ok}</div>}
    </form>
  </main>;
}
