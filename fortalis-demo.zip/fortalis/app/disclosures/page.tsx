export default function Disclosures(){
  return <main className="prose prose-zinc dark:prose-invert max-w-3xl mx-auto px-6 py-16">
    <h1>Risk Disclosures</h1>
    <p>Investing involves risk. Past performance is not indicative of future results.</p>
  </main>;
}
