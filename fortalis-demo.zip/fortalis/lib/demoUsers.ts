import bcrypt from "bcryptjs";

export type DemoUser = {
  id: string;
  name: string;
  email: string;
  role: "admin" | "user";
  passwordHash: string;
  twoFAEnabled?: boolean;
};

// Demo store in-memory (replace with DB in production)
const password = "demo1234";
const hash = bcrypt.hashSync(password, 10);

export const demoUsers: DemoUser[] = [
  { id: "1", name: "Admin", email: "admin@fortalis.test", role: "admin", passwordHash: hash, twoFAEnabled: false },
  { id: "2", name: "Investor", email: "investor@fortalis.test", role: "user", passwordHash: hash, twoFAEnabled: false }
];

export async function findUserByEmail(email: string) {
  return demoUsers.find(u => u.email.toLowerCase() == email.toLowerCase()) || null;
}
