# Fortalis — Next.js Investment Platform (Demo)

A ready-to-deploy demo with:
- Landing + charts
- Auth (Credentials demo: `admin@fortalis.test` / `demo1234`)
- Admin dashboard
- API stubs (`/api/newsletter`, `/api/contact`)
- Legal pages (Privacy, Terms, Disclosures)
- Tailwind styles (minimal utility classes)
- Live chat hook (Crisp via `NEXT_PUBLIC_CRISP_WEBSITE_ID`)

## Quick start
```bash
npm i
cp .env.example .env.local
# set NEXTAUTH_SECRET to any strong random string
npm run dev
```

## Deploy free (Vercel)
- Push this folder to a new GitHub repo.
- Create a Vercel project from the repo.
- Add env vars in Vercel:
  - `NEXTAUTH_SECRET` (random 32+ chars)
  - `NEXTAUTH_URL` (Vercel URL)
  - `NEXT_PUBLIC_CRISP_WEBSITE_ID` (optional)
- Deploy. Visit `/signin` and use the demo credentials to test.

> NOTE: This build uses an **in-memory user store** for demonstration. Connect a database (e.g., Postgres + Prisma) for production, and wire email or OTP for 2FA.
